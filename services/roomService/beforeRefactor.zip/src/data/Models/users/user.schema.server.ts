/* const mongoos = require('mongoose');
let userSchema = mongoos.Schema({
                                     username: String,
                                     password: String,
                                     email: String,
                                     friends: [],
                                 }, {collection:'user'});

module.exports = userSchema;
 */