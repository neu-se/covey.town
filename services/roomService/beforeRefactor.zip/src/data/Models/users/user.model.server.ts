let mongooseD = require('mongoose');
let userSchemaImport = require('./user.schema.server');
let userModel = mongooseD.model('UserModel', userSchemaImport);

module.exports = userModel;