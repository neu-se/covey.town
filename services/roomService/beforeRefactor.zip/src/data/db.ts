//import { mongoose } from 'mongoose';
/* const MongoClient = require('mongodb').MongoClient;
const uri =
  'mongodb+srv://user:user@cluster0.y7ubd.mongodb.net/CoveyTown?retryWrites=true&w=majority';
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
const startDatabase = () => {
  client.connect(() => {
    console.log('MONGO DB Connected');
    const db = client.db('CoveyTown');
    db.createCollection('players');
    // perform actions on the collection object
  });
};

module.exports = startDatabase;
 */

/* const mongoose = require('mongoose');

const uri =
  'mongodb+srv://user:user@cluster0.y7ubd.mongodb.net/CoveyTown?retryWrites=true&w=majority';

let conn = mongoose.connect(uri);
module.exports = conn; */